# SaathiVerse AI — Android Starter (தமிழ்)

## இதில் என்ன இருக்கிறது?
- Android Studio project (Java + WebView)
- `app/src/main/assets/index.html` — தமிழ்/ஆங்கில AI companion UI demo
- Mood buttons, text chat demo, browser ஆதரித்தால் speech-to-text மற்றும் text-to-speech முயற்சி
- APK build செய்யத் தேவையான Gradle project files

## முக்கிய வரம்பு
இது **starter/demo app**. உண்மையான LLM/AI இணைப்பு இல்லை. தற்போதைய பதில்கள் HTML-ல் உள்ள sample rules-இல் இருந்து வருகின்றன. Voice input/output browser/WebView மற்றும் Android மொழி ஆதரவைப் பொறுத்தது. மனித உணர்ச்சிகள் என்று தவறாகக் கூறாமல், AI உருவாக்கும் உணர்ச்சி பாணி பதில்களாகவே வடிவமைக்கப்பட்டுள்ளது.

## APK உருவாக்குவது
1. கணினியில் Android Studio-வை நிறுவவும்.
2. இந்த ZIP-ஐ extract செய்யவும்.
3. Android Studio → **Open** → `SaathiVerseAI` folder-ஐ தேர்வு செய்யவும்.
4. Gradle sync முடியும் வரை காத்திருக்கவும். Android SDK Platform 35 நிறுவுமாறு கேட்டால் நிறுவவும்.
5. சோதிக்க, Android phone-ஐ USB debugging மூலம் இணைத்து **Run** அழுத்தவும்.
6. APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Debug APK பொதுவாக `app/build/outputs/apk/debug/app-debug.apk`-ல் கிடைக்கும்.

## உண்மையான AI சேர்க்க
- ஒரு AI provider-இன் API access தேவை.
- API key-ஐ Android app / HTML-க்குள் hardcode செய்ய வேண்டாம்.
- HTTPS backend (உதா. Node.js server) உருவாக்கி, key-ஐ server environment variable-ல் வைத்துக் கொள்ளவும்.
- App-இல் உள்ள `replyFor()` demo logic-ஐ backend endpoint-க்கு `fetch()` மூலம் மாற்றவும்.
- Voice input-க்கு Android SpeechRecognizer அல்லது ஆதரிக்கப்படும் browser Web Speech API; voice output-க்கு Android TextToSpeech அல்லது provider TTS பயன்படுத்தலாம்.
- API usage-க்கு செலவு/வரம்புகள் இருக்கலாம்; microphone அனுமதி பயனரிடம் கேட்க வேண்டும்.

## Build தேவைகள்
- Android Studio
- JDK 17 (Android Studio-வுடன் வரும் JBR பொதுவாகப் போதுமானது)
- Android SDK Platform 35 + Build Tools
